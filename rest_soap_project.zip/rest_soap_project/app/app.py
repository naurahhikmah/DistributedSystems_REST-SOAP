from flask import Flask, request, jsonify, Response
from flask_sqlalchemy import SQLAlchemy
import xml.etree.ElementTree as ET

app = Flask(__name__)

# Konfigurasi database SQLite
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///university.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Model Mahasiswa
class Mahasiswa(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nim = db.Column(db.String(50), unique=True, nullable=False)
    nama = db.Column(db.String(100), nullable=False)

# Model Mata Kuliah
class MataKuliah(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nama = db.Column(db.String(100), nullable=False)
    mahasiswa_id = db.Column(db.Integer, db.ForeignKey('mahasiswa.id'), nullable=False)
    mahasiswa = db.relationship('Mahasiswa', backref=db.backref('mata_kuliah', lazy=True))

# Inisialisasi database
with app.app_context():
    db.create_all()

# SOAP Endpoint
@app.route('/soap', methods=['POST'])
def soap_service():
    # Baca isi permintaan SOAP (XML)
    soap_request = request.data.decode('utf-8')
    
    # Parse XML dengan ElementTree
    root = ET.fromstring(soap_request)
    nim = root.find('.//nim').text if root.find('.//nim') is not None else None
    
    # Query the database for the student with the provided nim
    mahasiswa = Mahasiswa.query.filter_by(nim=nim).first()

    if mahasiswa:
        # Build the SOAP response with data from the database
        soap_response = f"""
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
            <soapenv:Body>
                <tns:GetStudentResponse xmlns:tns="http://127.0.0.1:5000/">
                    <nim>{mahasiswa.nim}</nim>
                    <nama>{mahasiswa.nama}</nama>
                </tns:GetStudentResponse>
            </soapenv:Body>
        </soapenv:Envelope>
        """
    else:
        # If the student was not found, return an error in the SOAP response
        soap_response = f"""
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
            <soapenv:Body>
                <tns:GetStudentResponse xmlns:tns="http://127.0.0.1:5000/">
                    <error>Student not found</error>
                </tns:GetStudentResponse>
            </soapenv:Body>
        </soapenv:Envelope>
        """
    
    return Response(soap_response, mimetype='text/xml')

# CRUD Mahasiswa
@app.route('/mahasiswa', methods=['GET', 'POST'])
def mahasiswa():
    if request.method == 'GET':
        mahasiswa_list = Mahasiswa.query.all()
        return jsonify([{'id': m.id, 'nim': m.nim, 'nama': m.nama} for m in mahasiswa_list])

    elif request.method == 'POST':
        data = request.get_json()
        new_mahasiswa = Mahasiswa(nim=data['nim'], nama=data['nama'])
        db.session.add(new_mahasiswa)
        db.session.commit()
        return jsonify({'message': 'Mahasiswa added successfully!'}), 201

@app.route('/mahasiswa/<int:id>', methods=['GET', 'PUT', 'DELETE'])
def mahasiswa_detail(id):
    mahasiswa = Mahasiswa.query.get(id)
    if not mahasiswa:
        return jsonify({'error': 'Mahasiswa not found'}), 404

    if request.method == 'GET':
        return jsonify({'id': mahasiswa.id, 'nim': mahasiswa.nim, 'nama': mahasiswa.nama})

    elif request.method == 'PUT':
        data = request.get_json()
        mahasiswa.nim = data['nim']
        mahasiswa.nama = data['nama']
        db.session.commit()
        return jsonify({'message': 'Mahasiswa updated successfully!'})

    elif request.method == 'DELETE':
        db.session.delete(mahasiswa)
        db.session.commit()
        return jsonify({'message': 'Mahasiswa deleted successfully!'})

# CRUD Mata Kuliah
@app.route('/mata_kuliah', methods=['GET', 'POST'])
def mata_kuliah():
    if request.method == 'GET':
        mata_kuliah_list = MataKuliah.query.all()
        return jsonify([
            {'id': mk.id, 'nama': mk.nama, 'mahasiswa_id': mk.mahasiswa_id}
            for mk in mata_kuliah_list
        ])

    elif request.method == 'POST':
        data = request.get_json()
        new_mata_kuliah = MataKuliah(nama=data['nama'], mahasiswa_id=data['mahasiswa_id'])
        db.session.add(new_mata_kuliah)
        db.session.commit()
        return jsonify({'message': 'Mata Kuliah added successfully!'}), 201

@app.route('/mata_kuliah/<int:id>', methods=['GET', 'PUT', 'DELETE'])
def mata_kuliah_detail(id):
    mata_kuliah = MataKuliah.query.get(id)
    if not mata_kuliah:
        return jsonify({'error': 'Mata Kuliah not found'}), 404

    if request.method == 'GET':
        return jsonify({
            'id': mata_kuliah.id,
            'nama': mata_kuliah.nama,
            'mahasiswa_id': mata_kuliah.mahasiswa_id
        })

    elif request.method == 'PUT':
        data = request.get_json()
        mata_kuliah.nama = data['nama']
        mata_kuliah.mahasiswa_id = data['mahasiswa_id']
        db.session.commit()
        return jsonify({'message': 'Mata Kuliah updated successfully!'})

    elif request.method == 'DELETE':
        db.session.delete(mata_kuliah)
        db.session.commit()
        return jsonify({'message': 'Mata Kuliah deleted successfully!'})

# Jalankan aplikasi
if __name__ == '__main__':
    app.run(debug=True)
